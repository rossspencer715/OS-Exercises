#include <unistd.h> 
#include <iostream>
#include <stdio.h> 
#include <sys/socket.h> 
#include <stdlib.h> 
#include <netinet/in.h> 
#include <string.h> 
#include <vector>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <arpa/inet.h>

/*
**
**	Special thanks to http://www.linuxhowtos.org/C_C++/socket.htm for walking me through sockets
**  Also special thanks to https://www.thecrazyprogrammer.com/2017/06/socket-programming.html which was what I used initially until I found linuxhowtos
**
*/

int main(int argc, char const *argv[]){
	if(argc < 2){
		std::cout << "ERROR: no port given.\n";
		return 1;
	}

	char datastream[2600];
	// IP is default 0 protocol
	int sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0){
        std::cout << "ERROR opening socket\n";
        return 1;
	}
	int portnum = atoi(argv[1]);
	struct sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	serverAddr.sin_port = htons(portnum);
	int clientConnected = connect(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr));
	if(clientConnected < 0){
        std::cout << "Connection not established.\n";
        return 1;
    }
    /*else{
    	std::cout << "Client connected\n";
    }*/
    while(true){
    	std::string input;
		std::getline(std::cin, input);
		//std::cout << " our input is " << input << "\n\n";
		if(input[0] == 'p'){
			//remove p and space
			input.erase(0,2);
			int index = std::stoi(input);
			//std::cout << index << " is our index lol\n\n\n";
			std::cout << "Please enter your hiss:\n";
			std::getline(std::cin, input);
			if(input.length() > 140){
				std::cout << "ERROR: Message is too long.";
				return 1;
			}
			unsigned int msgLen = input.length();
			//char* datastreamy = new char[msgLen + 4];
			bzero(datastream, 2600);
			datastream[0] = 'p';
			sprintf(&datastream[1], "%d", index);
			sprintf(&datastream[2], "%d", msgLen);
			//datastreamy[2] = *(char*)&msgLen;
			for(int i = 0; i < msgLen; i++){
				datastream[3 + i] = input[i];
			}
			datastream[msgLen + 3] = '\0';
			/*for(int k = 0; k < msgLen + 4; k++){
				std::cout << datastreamy[k];
			}*/
			//std::cout << " is our string\n\n";
			int n = write(sockfd, datastream, strlen(datastream));
    		if(n < 0){
         		std::cout << "ERROR writing to socket";
         		return 1;
    		}
    		//bzero(datastream, 2600);
    		//n = read(sockfd,datastream, 2600);
    		//if (n < 0) 
         	//	std::cout << "ERROR reading from socket";
			

		}
		else if(input.compare("g") == 0){
			//char* datastreamy = new char[2600];
			bzero(datastream, 2600);
			datastream[0] = 'g';
			datastream[1] = '\0';
			//send the g
			int n = write(sockfd, datastream, strlen(datastream));
			//read the 0. 1. ...
    		n = read(sockfd,datastream, 2600);
    		if (n < 0){
         		std::cout << "ERROR reading from socket";
         		return 1;
    		}
         	std::cout << datastream;
         	
		}
		else if(input.compare("k") == 0){
			//char* datastream = new char[2600];
			bzero(datastream, 2600);
			datastream[0] = 'k';
			datastream[1] = '\0';
			//send the k
			int n = write(sockfd, datastream, strlen(datastream));
			close(sockfd);
			return 0;
		}
		else{
			break;
		}
		//std::cout << "end of while loop\n\n";
    }
    
    close(sockfd);

   	return 0;
}