#include <unistd.h> 
#include <iostream>
#include <stdio.h> 
#include <sys/socket.h> 
#include <stdlib.h> 
#include <netinet/in.h> 
#include <string.h> 
#include <vector>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <arpa/inet.h>

/*
**
**	Special thanks to http://www.linuxhowtos.org/C_C++/socket.htm for walking me through sockets
**  Also special thanks to https://www.thecrazyprogrammer.com/2017/06/socket-programming.html which was what I used initially until I found linuxhowtos
**
*/

int main(int argc, char const *argv[]){
	if(argc < 2){
		std::cout << "ERROR: no port given.\n";
	}

	char datastream[2600];
	std::vector<std::string> strings;
	for(int i = 0; i < 10; i++)
		strings.push_back("");
	// IP is default 0 protocol
	int sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0){
        std::cout << "ERROR opening socket";
        return 1;
	}
	else{
		std::cout << "Listening at port: " << argv[1] << "\n";
	}
	int portnum = atoi(argv[1]);

	int clientConnected = 0;
	struct sockaddr_in serverAddr, clientAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_addr.s_addr = htonl(INADDR_ANY); //https://stackoverflow.com/questions/6081892/does-sin-addr-s-addr-inaddr-any-need-htonl-at-all
	serverAddr.sin_port = htons(portnum);
	int bound = bind(sockfd, (struct sockaddr*)&serverAddr , sizeof(serverAddr));
	if(bound < 0){
		std::cout << "ERROR: couldn't bind.\n";
		return 1;
	}
	listen(sockfd, 5);
	unsigned int clientLen = sizeof(clientAddr);
	int newsockfd = accept(sockfd, (struct sockaddr *) &clientAddr, &clientLen);
	if (newsockfd < 0){
        std::cout << "ERROR on accept";
        return 1;
	}

    
    int n = 1;
    while(n > 0){
    	bzero(datastream, 2600);
    	n = read(newsockfd, datastream, 2600);
    	//std::cout << datastream << " is our datastream\n\n";
    	if(datastream[0] == 'p'){
    		//printf("Here is the message: %s\n", datastream);
    		char a = datastream[1];
    		int b = -1;
    		if(a - '0' > 9 || a - '0' < 0){
    			std::cout << "ERROR: index out of bounds\n";
    			return 1;
    		}
    		else{
    			b = a - '0';
    		}
    		int digitCtr;
    		//a = datastream[2];
    		//unsigned int length = *(unsigned int *)&a;

    		std::string input(datastream);
    		//erase command and position
    		input.erase(0,2);
    		//erase the length too?? unnecessary?
    		input.erase(0,1);
    		//std::cout << "test1\n\n";
    		strings[b] = input;
    		//std::cout << "test2\n\n";
			/*n = write(newsockfd,"I got your message",18);
			if(n < 0){
				std::cout << "ERROR: write unsuccessful\n";
			}*/
			//for(int i = 0; i < 10; i++){
			//	std::cout << i << ". " << strings[i] <<"\n";
			//}
    	}
    	else if(datastream[0] == 'k'){
    		close(newsockfd);
    		close(sockfd);
    		std::string str = "Final contents:\n";
    		for(int i = 0; i < 10; i++){
    			str = str + "" + std::to_string(i) + ". " + strings[i] + "\n";
    		}
    		std::cout << str;
    		return 1;
    	}
    	//read the g
    	else if(datastream[0] == 'g'){
    		//std::cout << "we gotta g\n\n\n";
    		std::string str = "";
    		for(int i = 0; i < 10; i++){
    			str = str + "" + std::to_string(i) + ". " + strings[i] + "\n";
    		}
    		const char *cstr = str.c_str();
    		//send the 0. 1. ... string
    		n = write(newsockfd, cstr, strlen(cstr));
    		if(n < 0){
    			std::cout << "ERROR writing to socket";
    			return 1;
    		}

    	}
    	else{
    		close(newsockfd);
    		close(sockfd);
    		std::cout << "ERROR: invalid input\n";
    		return 1;
    	}
    }
	
    if(n < 0){
    	std::cout << "ERROR reading from socket";
    	return 1;
    }
    
    close(newsockfd);
    close(sockfd);
     

	return 0;
}
